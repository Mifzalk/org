declare module "satellite.js";

